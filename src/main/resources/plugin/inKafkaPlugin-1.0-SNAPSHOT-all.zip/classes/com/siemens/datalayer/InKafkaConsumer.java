package com.siemens.datalayer;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * InKafkaConsumer implement consumer interfaces for Kafka
 * @author z0043hxf
 * @date 2021/11/02
 */
public class InKafkaConsumer extends AbstractRealtimeConsumer {
    /**
     * executorService is a single thread pool to run task thread receiving Kafka message
     */
    ExecutorService executorService;

    /**
     * The real working class handling Kafka connection and message
     */
    InKafkaLiteConsumer task;

    /**
     * Store InKafkaEndpoint to access configure information later
     * @param endpoint
     */
    public InKafkaConsumer(RealtimeEndpoint endpoint) {
        realtimeEndpoint = endpoint;
    }

    /**
     * Create the worker for Kafka message handling, and run it
     */
    @Override
    public void start() {
        task = new InKafkaLiteConsumer(this);
        executorService = new ThreadPoolExecutor(1, 1, 1000000, TimeUnit.SECONDS, new LinkedBlockingQueue());
        executorService.submit(task);
    }

    /**
     * Set stop flag in worker, and then shutdown the thread pool
     */
    @Override
    public void stop() {
        task.shutdown();
        executorService.shutdown();

        /**
         * Function tracing information
         */
//        System.out.println("plugin stop!");
    }
}
