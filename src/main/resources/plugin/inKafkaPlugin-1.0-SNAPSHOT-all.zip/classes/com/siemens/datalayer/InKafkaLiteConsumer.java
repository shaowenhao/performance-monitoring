package com.siemens.datalayer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;

/**
 * The worker class to handling Kafka connection and message
 * It implement Runnable interface to run in thread pool
 * @author z0043hxf
 * @date 2021/11/02
 */
public class InKafkaLiteConsumer implements Runnable{
    /**
     * The real kafka consumer class
     */
    private KafkaConsumer<String, String> kafkaConsumer;

    /**
     * InKafkaConsumer containing configure information
     */
    private InKafkaConsumer inKafkaConsumer;

    /**
     * Properties used to create KafkaConsumer instance
     */
    private Properties kafkaConfiguration;

    /**
     * Running flag to stop the run thread
     */
    Boolean runningFlag = true;

    /**
     * InKafkaConsumer
     * @param inKafkaConsumer
     */
    public InKafkaLiteConsumer(InKafkaConsumer inKafkaConsumer) {
        this.inKafkaConsumer = inKafkaConsumer;
        InKafkaEndpoint endpoint = (InKafkaEndpoint)inKafkaConsumer.getRealtimeEndpoint();
        kafkaConfiguration = endpoint.getConfiguration();
    }

    @Override
    public void run() {
        /**
         * Function tracing information
         * When debug finished, it can be commented
         */
        System.out.println("InKafkaLiteConsumer run:==========================");

        /**
         * Convert configure information from kafkaConfiguration to KafkaConsumer needed format.
         * During develop, test value can be used first before using real configure information.
         */
        Properties properties = new Properties();
//        properties.put("bootstrap.servers", "localhost:9092");
        properties.put("bootstrap.servers", kafkaConfiguration.get("brokers").toString() );

//        properties.put("group.id", "mygroup");
        properties.put("group.id", kafkaConfiguration.get("groupId"));

//        properties.put("auto.commit.interval.ms", "1000");
        properties.put("auto.commit.interval.ms", kafkaConfiguration.get("AutoCommitIntervalMs").toString());

//        properties.put("enable.auto.commit", "true");
        properties.put("enable.auto.commit", kafkaConfiguration.get("autoCommitEnable").toString());

        /**
         * Function tracing information
         * When debug finished, it can be commented
         */
        System.out.println("InKafkaLiteConsumer run with bootstrap.servers:"+kafkaConfiguration.get("brokers").toString());
        System.out.println("InKafkaLiteConsumer run with group.id:"+kafkaConfiguration.get("groupId").toString());
        System.out.println("InKafkaLiteConsumer run with auto.commit.interval.ms:"+kafkaConfiguration.get("AutoCommitIntervalMs").toString());
        System.out.println("InKafkaLiteConsumer run with enable.auto.commit:"+kafkaConfiguration.get("autoCommitEnable").toString());
        System.out.println("InKafkaLiteConsumer run with topic:"+kafkaConfiguration.get("topic").toString());

        /**
         * Create the real KafkaConsumer instance.
         * In case none value return, during develop some check tracing can add around there like
         * try {
         *             kafkaConsumer = new KafkaConsumer<String, String>(properties, new StringDeserializer(), new StringDeserializer());
         *
         *         }
         *         finally {
         *             //Function tracing information
         *             if(null==kafkaConsumer) {
         *                 System.out.println("InKafkaLiteConsumer run:========================== null==kafkaConsumer");
         *             }
         *         }
         *
         * Default log is not properly set will cause this issue. Please refer to pom.xml for more information.
         */
        kafkaConsumer = new KafkaConsumer<String, String>(properties, new StringDeserializer(), new StringDeserializer());

        /**
         * subscribe topic, and set test value before using real configure during development
         */
//        this.kafkaConsumer.subscribe(Collections.singletonList("test"));
        this.kafkaConsumer.subscribe(Collections.singletonList((String)kafkaConfiguration.get("topic")));

        /**
         * Get auto commit setting
         */
        boolean isAutoCommitEnable = true;
        if(!(((String) kafkaConfiguration.get("autoCommitEnable")).isEmpty())) {
            isAutoCommitEnable = Boolean.parseBoolean((String) kafkaConfiguration.get("autoCommitEnable"));
        }

        /**
         * Function tracing information
         * When debug finished, it can be commented
         */
        if(isAutoCommitEnable) {
            System.out.println("InKafkaLiteConsumer run:========================== AutoCommit Enabled");
        } else {
            System.out.println("InKafkaLiteConsumer run:========================== Manual commit");
        }

        /**
         * Check if run flag is set to false or not. If true, continue poll message
         */
        while (runningFlag) {
            ConsumerRecords<String, String> records = kafkaConsumer.poll(Duration.ofMillis(Long.parseLong((String) kafkaConfiguration.get("AutoCommitIntervalMs"))));
            for (ConsumerRecord<String, String> record : records) {
                System.out.println(record.value());
                /**
                 * In data layer, real hook will be injected and called here to collect data
                 */
                Hook hook = inKafkaConsumer.getHook();
                if(null!=hook) {
                    hook.flashPayload(record.value());
                }
            }
            /**
             * Commit manually if it is needed
             */
            if(!isAutoCommitEnable) {
                kafkaConsumer.commitSync();
            }
        }

        /**
         * Do not forget to close kafkaConsumer
         */
        kafkaConsumer.close();
    }

    /**
     * Setting run flag to false, thus stop the run thread
     */
    public void shutdown() {
        runningFlag =false;
    }

}
