package com.siemens.datalayer;

import java.util.Map;
import java.util.Properties;

/**
 * InKafkaEndpoint is used by the framework to generate producer and/or consumer.
 * It stores configure information passed from InKafkaComponent.
 * @author z0043hxf
 * @date 2021/11/02
 */
public class InKafkaEndpoint extends AbstractRealtimeEndpoint{
    /**
     * Property from URI
     */
    Properties kafkaConfiguration;
    /**
     * Parameters
     */
    private Map<String, Object> parameters;

    public InKafkaEndpoint(RealtimeComponent component) {
        super(component);
    }

    @Override
    public RealtimeProducer createProducer() {
        return new InKafkaProducer(this);
    }

    @Override
    public RealtimeConsumer createConsumer() {
        return new InKafkaConsumer(this);
    }

    public Map<String, Object> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, Object> parameters) {
        this.parameters = parameters;
    }

    public Properties getConfiguration() {
        return kafkaConfiguration;
    }

    public void setConfiguration(Properties kafkaConfiguration) {
        this.kafkaConfiguration = kafkaConfiguration;
    }
}
