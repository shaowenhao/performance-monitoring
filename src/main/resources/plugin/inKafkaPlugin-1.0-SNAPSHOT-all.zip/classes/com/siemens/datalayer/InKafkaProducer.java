package com.siemens.datalayer;


/**
 * InKafkaProducer is not used in the framework.
 * This demo only give empty implements for AbstractRealtimeProducer
 * @author z0043hxf
 * @date 2021/11/02
 */

public class InKafkaProducer extends AbstractRealtimeProducer{
    private int sendCount =0;
    private static int printGap = 10000;
    public InKafkaProducer(RealtimeEndpoint endpoint) {
        this.realtimeEndpoint = endpoint;
    }

    @Override
    public void sendPayload(Object object) {
        sendCount++;
        if(sendCount%printGap==0) {
            System.out.println("At "+System.currentTimeMillis()+" InKafkaProducer receive message count:"+sendCount);
        }
    }
}
