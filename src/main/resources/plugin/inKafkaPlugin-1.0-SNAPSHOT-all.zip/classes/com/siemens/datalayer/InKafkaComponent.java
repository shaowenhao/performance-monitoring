package com.siemens.datalayer;

import org.apache.commons.lang3.StringUtils;
import org.pf4j.Extension;

import java.util.*;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.mapping;
import static java.util.stream.Collectors.toList;

/**
 * A demo plugin InKafkaComponent implemented 2 extension points
 * The interface createEndpoint returns an endpoint with configure from input uri or parameters
 * The interface componentType returns the componentType, e.g. InKafka, ROCKETMQ, RabbitMQ
 *
 * @Extension telling pf4j this is a concrete implementation of an extension point.
 * @author z0043hxf
 * @date 2021/11/02
 */
@Extension
public class InKafkaComponent extends AbstractRealtimeComponent{
    /**
     * Create an endpoint later to generate consumer and/or producer. In this demo, uri is really used.
     * @param remaining uri format ,such as param1:value1&param2=value2
     *                  for Kafka, it is like following
     *                  brokers=localhost:9092&AutoCommitIntervalMs=1000&autoCommitEnable=false&groupId=test1&topic=test
     * @param parameters parameters with configure information.
     * @return
     */
    @Override
    public RealtimeEndpoint createEndpoint(String remaining, Map<String, Object> parameters) {
        /**
         * Create InKafkaEndpoint endpoint
         */
        InKafkaEndpoint endpoint = new InKafkaEndpoint(this);

        /**
         * Get configure information from input URI
         */
        Map<String, List<String>> stringListMap = splitQuery(remaining);

        /**
         * Set up properties with configure information. Different component type has different configure.
         * For Kafka, brokers, group id, topic, auto commit flag and auto commit interval are passed in.
         */
        Properties kafkaConfiguration = new Properties();
        Optional.ofNullable(stringListMap.get("topic")).ifPresent(topic -> kafkaConfiguration.setProperty("topic",topic.get(0)));
        Optional.ofNullable(stringListMap.get("autoCommitEnable")).ifPresent(autoCommitEnable -> kafkaConfiguration.setProperty("autoCommitEnable",autoCommitEnable.get(0)));
        Optional.ofNullable(stringListMap.get("groupId")).ifPresent(groupId -> kafkaConfiguration.setProperty("groupId",groupId.get(0)));
        Optional.ofNullable(stringListMap.get("brokers")).ifPresent(brokers -> kafkaConfiguration.setProperty("brokers",brokers.get(0)));
        Optional.ofNullable(stringListMap.get("AutoCommitIntervalMs")).ifPresent(autoCommitIntervalMs -> kafkaConfiguration.setProperty("AutoCommitIntervalMs",autoCommitIntervalMs.get(0)));

        /**
         * Set endpoint configure information.
         */
        endpoint.setConfiguration(kafkaConfiguration);

        /**
         * If needed, parameters can also be saved for use later.
         */
        endpoint.setParameters(parameters);

        /**
         * The endpoint well configured is returned. The framework will use it to generate producer or consumer later.
         */
        return endpoint;
    }

    /**
     * return this plugin type of InKafka, this value is used by datalayer's realtime driver type
     * @return plugin type of InKafka
     */
    @Override
    public String componentType() {
        return "InKafka";
    }

    /**
     * Function to split uri and return configured name and value
     * @param uri
     * @return
     */
    public Map<String, List<String>> splitQuery(String uri) {
        if (StringUtils.isEmpty(uri)) {
            return Collections.emptyMap();
        }
        return Arrays.stream(uri.split("&"))
                .map(this::splitQueryParameter)
                .collect(Collectors.groupingBy(AbstractMap.SimpleImmutableEntry::getKey, LinkedHashMap::new, mapping(Map.Entry::getValue, toList())));
    }

    public AbstractMap.SimpleImmutableEntry<String, String> splitQueryParameter(String it) {
        final int idx = it.indexOf("=");
        final String key = idx > 0 ? it.substring(0, idx) : it;
        final String value = idx > 0 && it.length() > idx + 1 ? it.substring(idx + 1) : null;
        return new AbstractMap.SimpleImmutableEntry<>(key, value);
    }

}
